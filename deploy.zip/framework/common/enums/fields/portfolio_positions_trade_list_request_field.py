from enum import Enum
class PortfolioPositionTradeListRequestFields(Enum):
    PositionId=1
