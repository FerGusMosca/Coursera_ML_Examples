class DateRangeClassificationValue:


    def __init__(self,p_id,p_key,p_date_start,p_date_end,p_classification):
        self.id=p_id
        self.key=p_key
        self.date_start=p_date_start
        self.date_end=p_date_end
        self.classification=p_classification