class ImageTrainRow():


    def __init__(self,p_X,p_Y,p_image):
        self.X=p_X
        self.Y =p_Y
        self.image=p_image