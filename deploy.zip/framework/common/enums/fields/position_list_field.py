from enum import Enum
class PositionListField(Enum):
    Positions=1
    Status=2
    Error=3
