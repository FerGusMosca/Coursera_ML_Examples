from enum import Enum
class TimeUnit(Enum):
    Minute = '0'
    Hour = '1'
    Day = '2'
    Week = '3'
