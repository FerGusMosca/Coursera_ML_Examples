from enum import Enum
class TickDirection(Enum):
    PlusTick = 0
    ZeroPlusTick = 1
    MinusTick = 2
    ZeroMinusTick = 3