from enum import Enum
class TradingSignalField(Enum):
    Symbol = 1
    Signal=2
    Recommendation=3
