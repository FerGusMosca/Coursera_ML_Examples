from enum import Enum
class Side(Enum):
    Buy = '1'
    Sell = '2'
    Unknown = '0'
    SellShort='s'
    BuyToClose='c'
