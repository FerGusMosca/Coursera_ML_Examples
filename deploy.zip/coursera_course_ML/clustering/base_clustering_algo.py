from common.BaseAlgo import BaseAlgo


class BaseClusteringAlgo(BaseAlgo):

    def __init__(self):
        pass