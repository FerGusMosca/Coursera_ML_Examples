from enum import Enum
class PortfolioPositionFields(Enum):
    PortfolioPosition=1

