from enum import Enum
class TradeFields(Enum):
    Trade=1
    PositionId=2
