from enum import Enum
class StrategyBacktestField(Enum):
    Symbol=1
    ReferenceDate =2
    CandleBarDict=3
    MarketDataDict = 4
    ModelParametersDict=5
