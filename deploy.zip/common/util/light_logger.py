class LightLogger():


    def __init__(self):
        pass


    @staticmethod
    def do_log(msg):
        print(msg)