from enum import Enum
class ExecutionReportListField(Enum):
    ExecutionReports=1
