
import numpy as np

class NeuralNetworksWeek2Test():

    @staticmethod
    def test():

        a=np.array([[1,1],[1,-1]])
        b=np.array([[2],[3]])

        c=a+b

        pass



