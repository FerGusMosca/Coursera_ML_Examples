from enum import Enum
class ErrorField(Enum):
    Exception=1
    ErrorMessage=2

