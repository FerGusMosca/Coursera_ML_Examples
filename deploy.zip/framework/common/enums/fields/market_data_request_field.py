from enum import Enum
class MarketDataRequestField(Enum):
    Symbol=1
    Exchange=2
    SecurityType=3
    SubscriptionRequestType=4
    Currency=5
    MDReqId=6