from enum import Enum
class StrategyBacktestResultField(Enum):
    Symbol=1
    Results =2
